package com.example.orchestrator.task;

public enum TaskStatus {
    READY,
    IN_PROGRESS,
    COMPLETED
}
