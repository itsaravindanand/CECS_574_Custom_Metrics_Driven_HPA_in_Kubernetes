SHOW DATABASES;

USE `tdc-test`;

SHOW TABLES;

SELECT * from task;

TRUNCATE TABLE task;

DROP TABLE task;